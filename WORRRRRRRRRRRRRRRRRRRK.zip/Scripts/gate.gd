extends Area2D

@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D
@onready var collision_shape_2d: CollisionShape2D = $CollisionShape2D
@export var frame = 0
var open = false
signal load_room

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	animated_sprite_2d.frame = frame


func openUp():
	if animated_sprite_2d.frame != 2:
		animated_sprite_2d.play("Open")

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if animated_sprite_2d.frame == 2:
		open = true
	else:
		open = false


#func _on_area_entered(area: Area2D) -> void:
	#if open:
		#print("collider working")
		#emit_signal("load_room")
		#


func _on_body_entered(body: Node2D) -> void:
	if not body is TileMap and open:
		emit_signal("load_room")
